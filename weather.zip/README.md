**Weather Update**
# Technologies
* PHP
* Bootstrap
* Weather API

# Demo
http://sayedahammed.com/weather/